<?php $__env->startSection('content'); ?>




<div class="product-section mt-150 mb-150">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <div class="product-filters">
                    <ul>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li data-filter="._<?php echo e($item -> id); ?>"><?php echo e($item -> name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="active" data-filter="*">الكل</li>

                    </ul>
                </div>
            </div>
        </div>

        <div class="row product-lists">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 text-center _<?php echo e($item -> category_id); ?>">
                <div class="single-product-item">
                    <div class="product-image">
                        <a href="/products/<?php echo e($item->id); ?>"><img style="max-height: 250px;min-height:250px"  src="<?php echo e(asset('storage/' . $item->image)); ?>" alt=""></a>
                    </div>
                    <h3><?php echo e($item -> name); ?></h3>
                    <p class="product-price"> <?php echo e($item-> price); ?>$ </p>
                    <p class="product-price"><span>Quantity </span> <?php echo e($item-> quantity); ?> </p>



                    <a href="/cart" onclick="event.preventDefault(); document.getElementById('add-to-cart-form-<?php echo e($item->id); ?>').submit();" class="cart-btn">
                        <i class="fas fa-shopping-cart"></i>
                        اضافة الى السلة
                    </a>

                    <form id="add-to-cart-form-<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('cart.add', $item->id)); ?>" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <!-- Include any other form fields if needed -->
                    </form>





                    <form action="/products/delete/<?php echo e($item->id); ?>" method="POST" style="display:inline;">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?');">
                            <i class="fas fa-trash"></i> حذف المنتج
                        </button>
                    </form>

                        <a href="/products/<?php echo e($item->id); ?>/edit" class="btn btn-primary">
                            <i class="fas fa-trash"></i>
                            تعديل المنتج
                        </a>
                    </p>


                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="pagination-wrap">
                    <ul>
                        <li><a href="#">Prev</a></li>
                        <li><a href="#">1</a></li>
                        <li><a class="active" href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">Next</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/category.blade.php ENDPATH**/ ?>
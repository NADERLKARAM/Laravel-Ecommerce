<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\E-commerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5" style="text-align:center">


        <form action="/storeProductImage" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="row mt-5 mb-5">
                <input type="hidden" style="width: 100%" name="product_id" id="product_id" value="<?php echo e($product->id); ?>">



                <div class="col-9  pt-3">
                    <input type="file" class="form-control" name="photo" id="photo">
                </div>

                <div class="col-3">
                    <input type="submit" class="w-100" value="حفظ">
                </div>

                <span class="text-danger">
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
            </div>
        </form>





        <div class="row">
            <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4">
                    <img class="m-2" src="<?php echo e(asset($item->image_path)); ?>" width="300" height="300" alt="">
                    
                    <a href="/removeproductphoto/<?php echo e($item->id); ?>" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                        حذف الصورة
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/products/AddProductImage.blade.php ENDPATH**/ ?>
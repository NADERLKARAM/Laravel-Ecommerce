<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e($product->name); ?>

                    </div>
                    <div class="card-body">
                        <p>description :<?php echo e($product->description); ?></p>
                        <p>Price: $<?php echo e($product->price); ?></p>

                        

                        <div class="product-image">
                            <a href="single-product.html"><img src="assets/img/dd.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/products/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>


<?php echo e(Session('username')); ?>


<div class="product-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-center">
                <div class="section-title">
                    <h3><span class="orange-text">أقسام</span> الموقع</h3>
                    <p>متعة التسوق عبر فروعنا</p>
                </div>
            </div>
        </div>

        <div class="row">




                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="single-product-item">
                        <div class="product-image">
                            <a href="<?php echo e(route('category.products', ['categoryID' => $item->id])); ?>">
                                <img style="max-height: :250px !important; min-height:250px !important"
                                 src="<?php echo e(asset('storage/' . $item->image)); ?>" alt=""></a>
                        </div>
                        <h3><?php echo e($item -> name); ?></h3>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
















<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/welcome.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="cart-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="cart-table-wrap">
                    <table class="cart-table">
                        <thead class="cart-table-head">
                            <tr class="table-head-row">
                                <th class="product-remove"></th>
                                <th class="product-image">Product Image</th>
                                <th class="product-name">ID</th>
                                <th class="product-name">Name</th>
                                <th class="product-price">Price</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-total">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="table-body-row">
                                <td class="product-remove">
                                    <form action="<?php echo e(route('cart.remove', ['product' => $item->product->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?> <!-- Use 'delete' method for removing a specific product -->
                                        <button type="submit" class="remove-button"><i class="far fa-window-close"></i></button>
                                    </form>
                                </td>
                                <td>
                                    <img src = '<?php echo e(asset('storage/' . $item->product->image)); ?>' width="100" height="100" />
                                </td>
                                <td class="product-id"><?php echo e($item->product->id); ?></td>
                                <td class="product-name"><?php echo e($item->product->name); ?></td>
                                <td class="product-price">$<?php echo e($item->product->price); ?></td>
                                <td class="product-quantity">
                                    <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" placeholder="0" min="0">
                                </td>

                                <td class="product-total">$<?php echo e($item->product->price * $item->quantity); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="total-section">
                    <table class="total-table">
                        <thead class="total-table-head">
                            <tr class="table-total-row">
                                <th>Total</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="total-data">
                                <td><strong>Total: </strong></td>
                                <td>
                                    <?php echo e($products->sum(function ($item) {
                                        return $item->product->price * $item->quantity;
                                    })); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="cart-buttons">
                        <a href="/Completeorder" class="boxed-btn black">Check Out</a>
                        <?php if(auth()->check() && auth()->user()->role == 'admin'): ?>
                        <a href="/getAllOrders" class="boxed-btn black">getAllOrders</a>
                        <?php endif; ?>

                        <?php if(auth()->check() && auth()->user()->role == 'user'): ?>
                        <a href="/getAllOrdersWithUserAuth" class="boxed-btn black">getAllOrders</a>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="coupon-section">
                    <h3>Apply Coupon</h3>
                    <div class="coupon-form-wrap">
                        <form action="index.html">
                            <p><input type="text" placeholder="Coupon"></p>
                            <p><input type="submit" value="Apply"></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/cart/index.blade.php ENDPATH**/ ?>
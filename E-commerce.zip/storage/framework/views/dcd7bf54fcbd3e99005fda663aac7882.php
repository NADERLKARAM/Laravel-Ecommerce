<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>





<?php $__env->startSection('content'); ?>


<div class="container mt-5 mb-5">
<div class="text-right">
    <a href="/products/create" class="btn btn-primary mt-5 mb-5 w-50 ">
        اضافة المنتج
        <i class="fas fa-plus"></i>
    </a>
</div>

<table id="myTable" class="display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>image</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item -> id); ?></td>
            <td><?php echo e($item -> name); ?></td>
            <td><?php echo e($item -> price); ?></td>
            <td><?php echo e($item -> quantity); ?></td>
            <td>
                <img src = '<?php echo e(asset('storage/' . $item->image)); ?>' width="100" height="100" />
            </td>
            <td>
                <a href="/products/<?php echo e($item->id); ?>/edit" class="btn btn-primary">
                    <i class="fas fa-trash"></i>
                    تعديل المنتج
                </a>


                <form action="/products/delete/<?php echo e($item->id); ?>" method="POST" style="display:inline;">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?');">
                        <i class="fas fa-trash"></i> حذف المنتج
                    </button>
                </form>

                <a href="/AddProductImages/<?php echo e($item->id); ?>" class="btn btn-dark">
                    <i class="fas fa-images"></i>
                    اضافة صور المنتج
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>


</div>
<?php $__env->stopSection(); ?>




<script>
    $(document).ready( function () {
        let table = new DataTable('#myTable');
});
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/Products/ProductsTable.blade.php ENDPATH**/ ?>
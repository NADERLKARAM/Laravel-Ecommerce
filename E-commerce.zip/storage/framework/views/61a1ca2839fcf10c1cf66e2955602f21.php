<?php $__env->startSection('content'); ?>


        <div class="product-section mt-150 mb-150">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2 text-center">
                        <div class="section-title">
                            <h3><span class="orange-text">Add</span> Products </h3>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 mb-5 mb-lg-0">
                        <div class="form-title">
                        </div>
                        <div id="form_status"></div>
                        <div class="contact-form">


                                <form action="<?php echo e(route('categories.store')); ?>" method="post" enctype="multipart/form-data"style="text-align:right"  dir="rtl">
                                    <?php echo csrf_field(); ?>
                                <p>
                                    <input type="text" style="width: 100%" required placeholder="الاسم" name="name"
                                        id="name" value="<?php echo e(old('name')); ?>">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </p>


                                <p>
                                    <textarea name="description" required id="description" cols="30" rows="10" placeholder="description">

                                  <?php echo e(old('description')); ?>


                                </textarea>

                                </p>
                                <span class="text-danger">
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>


                                <p>
                                    <input type="file" class="form-control" name="image" id="image">

                                    <span class="text-danger">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>

                                </p>
                                <p><input type="submit" value="حفظ"></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/categories/addCategory.blade.php ENDPATH**/ ?>
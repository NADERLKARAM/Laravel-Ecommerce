<?php $__env->startSection('content'); ?>
<div class="checkout-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="checkout-accordion-wrap">
                    <div class="accordion" id="accordionExample">


                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card single-accordion">
                            <div class="card-header" id="headingOne">
                              <h5 class="mb-0">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                  Order Number <?php echo e($item -> id); ?>

                                </button>
                              </h5>
                            </div>

                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
                              <div class="card-body">
                                <div class="billing-address-form">
                                <form>

                                    <p><input type="tel" value="تم انشاء الاوردر بتاريخ : <?php echo e($item -> created_at); ?>" required id="phone" name="phone" placeholder="Phone"></p>
                                    <p><input type="text" value="<?php echo e($item -> name); ?>" required id="name" name="name" placeholder="Name"></p>
                                        <p><input type="email" value="<?php echo e($item -> email); ?>" required  id="email" name="email" placeholder="Email"></p>
                                        <p><input type="text" value="<?php echo e($item -> address); ?>" required  id="address" name="address" placeholder="Address"></p>
                                        <p><input type="tel" value="<?php echo e($item -> phone); ?>" required id="phone" name="phone" placeholder="Phone"></p>
                                        <p><textarea name="note"    id="note" cols="30" rows="10" placeholder="Say Something"><?php echo e($item -> note); ?></textarea></p>

                                </form>



                                    <div class="row">
                                        <div class="col-lg-8 col-md-12">
                                            <div class="cart-table-wrap">
                                                <table class="cart-table">
                                                    <thead class="cart-table-head">
                                                        <tr class="table-head-row">
                                                            <th class="product-remove">remove</th>
                                                            <th class="product-image">Product Image</th>
                                                            <th class="product-name">Name</th>
                                                            <th class="product-price">Price</th>
                                                            <th class="product-quantity">Quantity</th>
                                                            <th class="product-total">Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php $__currentLoopData = $item->OrderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="table-body-row">
                                                            <td class="product-remove">
                                                                <a href="/deletecartitem/<?php echo e($detail->id); ?>"><i class="far fa-window-close"></i></a>
                                                            </td>
                                                            <td class="product-image"><img src="<?php echo e(asset('storage/' . $detail->product->image)); ?>"
                                                                    alt=""></td>
                                                            <td class="product-name">
                                                                <a href="/products/<?php echo e($detail->product->id); ?>">
                                                                <?php echo e($detail->product->name); ?>

                                                                </a>
                                                            </td>
                                                            <td class="product-price"><?php echo e($detail->product->price); ?></td>
                                                            <td class="product-quantity"><?php echo e($detail->quantity); ?></td>
                                                            <td class="product-total">
                                                                <?php echo e($detail->product->price * $detail->quantity); ?> $</td>

                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="total-section">
                                                <table class="total-table">
                                                    <thead class="total-table-head">
                                                        <tr class="table-total-row">
                                                            <th>Total</th>
                                                            <th>Price</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <tr class="total-data">
                                                            <td><strong>Total: </strong></td>
                                                            <td>
                                                                <?php echo e($item->orderDetails->sum(function ($x) {
                                                                    return $x->product->price * $x->quantity;
                                                                })); ?>

                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div class="cart-buttons">

                                                 </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </div>

                </div>
            </div>

            <div class="col-lg-12 mt-5">


            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/orders/getOrder.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<!-- product section -->
<div class="product-section mt-150 mb-150">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-center">
                <div class="section-title">
                    <h3><span class="orange-text">اقسام</span> الموقع</h3>
                    <h4>متعة التسوق عبر موقعنا</h4>
                </div>
            </div>
        </div>


        <div class="row">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 text-center">
                <div class="single-product-item">
                    <div class="product-image">
                        <a href="/products/<?php echo e($item->id); ?>"><img
                                style="max-height: 250px;min-height:250px" src="<?php echo e(asset('storage/' . $item->image)); ?>"
                                alt=""></a>
                    </div>
                    <h3><?php echo e($item -> name); ?></h3>
                    <p class="product-price"><?php echo e($item->price); ?>$ </p>
                    <p class="product-price"><span>quantity </span> <?php echo e($item->quantity); ?> </p>


                    <a href="/cart" onclick="event.preventDefault(); document.getElementById('add-to-cart-form-<?php echo e($item->id); ?>').submit();" class="cart-btn">
                        <i class="fas fa-shopping-cart"></i>
                        اضافة الى السلة
                    </a>

                    <form id="add-to-cart-form-<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('cart.add', $item->id)); ?>" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <!-- Include any other form fields if needed -->
                    </form>


                    <?php if(auth()->check() && auth()->user()->role == 'admin'): ?>
                    <form action="/products/delete/<?php echo e($item->id); ?>" method="POST" style="display:inline;">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?');">
                            <i class="fas fa-trash"></i> حذف المنتج
                        </button>
                    </form>

                        <a href="/products/<?php echo e($item->id); ?>/edit" class="btn btn-primary">
                            <i class="fas fa-trash"></i>
                            تعديل المنتج
                        </a>

                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div style="text-align: center;    margin: 0px auto;">
            <?php echo e($products->links()); ?>

        </div>


    </div>
</div>
<!-- end product section -->
<?php $__env->stopSection(); ?>;

<style>
    svg {
        height: 50px !important;
    }
</style>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-commerce\resources\views/products/index.blade.php ENDPATH**/ ?>